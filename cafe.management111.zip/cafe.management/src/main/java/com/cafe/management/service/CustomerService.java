package com.cafe.management.service;

import com.cafe.management.entity.Customer;
import com.cafe.management.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    /**
     * Fetches all customers from the database.
     * @return List of all customers.
     */
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll(); // Uses JPA to fetch all records
    }

    /**
     * Fetches a customer by their ID.
     * @param id The ID of the customer.
     * @return Optional containing the customer if found, otherwise empty.
     */
    public Optional<Customer> getCustomerById(Long id) {
        return customerRepository.findById(id); // Uses JPA to find customer by ID
    }


    /**
     * Saves or updates a customer in the database.
     * @param customer The customer object to save.
     * @return The saved customer.
     */
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer); // Saves or updates the customer in the DB
    }

    /**
     * Deletes a customer by ID.
     * @param id The ID of the customer to delete.
     */
    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id); // Deletes the customer with the given ID
    }

}
