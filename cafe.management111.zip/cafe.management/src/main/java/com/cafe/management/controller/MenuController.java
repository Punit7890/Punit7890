package com.cafe.management.controller;

import com.cafe.management.entity.Menu;
import com.cafe.management.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;

    /**
     * Endpoint to retrieve all menu items.
     * @return HTTP response with a list of menu items.
     */
    @GetMapping("/all") // Handles GET requests at /api/menu/all
    public ResponseEntity<List<Menu>> getAllItems() {
      return ResponseEntity.ok(menuService.getAllItems()); // Returns the list of all menu items
    }

    /**
     * Endpoint to add a new menu item.
     * @param menu The menu item received from the request body.
     * @return HTTP response with the added menu item.
     */
    @PostMapping("/add") // Handles POST requests at /api/menu/add
    public ResponseEntity<Menu> addItem(@RequestBody Menu menu) {
      return ResponseEntity.ok(menuService.addItem(menu)); // Calls the service to add the item and returns it

    }

    /**
     * Endpoint to delete a menu item by ID.
     * @param id The ID of the item to be deleted.
     * @return HTTP response confirming deletion.
     */
    @DeleteMapping("/delete/{id}") // Handles DELETE requests at /api/menu/delete/{id}
    public ResponseEntity<String> deleteItem(@PathVariable Long id) {
        menuService.deletItem(id);  // Calls the service method to delete the item
        return ResponseEntity.ok("Item deleted successfully"); // Returns a confirmation message
    }
}
