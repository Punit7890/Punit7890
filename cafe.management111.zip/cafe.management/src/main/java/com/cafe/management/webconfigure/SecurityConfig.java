package com.cafe.management.webconfigure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity //it enables spring security for the application
public class SecurityConfig {

    // This method defines the security filter chain used to configure security rules
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // Disables CSRF protection since we're likely building a REST API
                .csrf(csrf -> csrf.disable())

                //defines authorization rules
                .authorizeHttpRequests(auth -> auth

                        // Allows unauthenticated access to endpoints under /auth/**
                        .requestMatchers("/auth/**").permitAll()

                        // All other requests require authentication
                        .anyRequest().authenticated()
                )
                //configures the app to be stateless (no HTTP sessions)
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                //enables basic HTTPS authentication with default setting
                .httpBasic(Customizer.withDefaults());

        // Builds and returns the configured security filter chain
        return http.build();
    }

    // This bean provides an AuthenticationManager, which is needed for manual authentication (e.g., login endpoint)
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    // This bean defines a PasswordEncoder to hash passwords using BCrypt algorithm (secure hashing for storing passwords)
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
