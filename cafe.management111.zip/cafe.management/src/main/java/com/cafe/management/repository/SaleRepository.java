package com.cafe.management.repository;

import com.cafe.management.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.LocalDateTime;
import java.util.List;

public interface SaleRepository extends JpaRepository<Sale, Long> {
    /**
     * Custom finder method provided by Spring Data JPA.
     * Finds all sales that occurred between a given start and end date.
     *
     * @param startDate The beginning of the date range
     * @param endDate   The end of the date range
     * @return List of Sale entities within the date range
     */
    List<Sale> findBySaleDateBetween(LocalDateTime startDate, LocalDateTime endDate);

    /**
     * Custom JPQL query to fetch all sales made after a certain date.
     *
     * @param start The start date to filter sales from
     * @return List of Sale entities with saleDate greater than or equal to the specified date
     */
    @Query("SELECT s FROM Sale s WHERE s.saleDate >= :start")
    List<Sale> findSalesAfter(LocalDateTime start);
}
