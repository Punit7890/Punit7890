package com.cafe.management.controller;

import com.cafe.management.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    /**
     * Endpoint to send an order confirmation email.
     * URL: POST /api/notifications/order
     *
     * @param email - recipient's email address (passed as a request parameter)
     * @param orderDetails - order details to include in the email (passed in request body)
     * @return HTTP 200 response with a success message
     */
    @PostMapping("/order")
    public ResponseEntity<String> sendOrderConfirmation(@RequestParam String email, @RequestBody String orderDetails) {
        notificationService.sendOrderConfirmation(email, orderDetails); //for order confirmation to customers
        return ResponseEntity.ok("Order Confirmation sent successfully.");
    }

    /**
     * This method is intended to send a daily sales summary email to admins or managers.
     * @param email - recipient's email address
     * @param summary - summary content to include in the email
     * @return HTTP 200 response with a success message
     */
    @PostMapping("/summary")
    public ResponseEntity<String> sendDailySalesSummary(@RequestParam String email, @RequestBody String summary) {
        notificationService.sendDailySalesSummary(email, summary); //for Daily summaries for admin
        return ResponseEntity.ok("Sales summary sent successfully.");
    }

}
