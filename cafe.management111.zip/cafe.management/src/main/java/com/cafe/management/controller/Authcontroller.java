package com.cafe.management.controller;

import com.cafe.management.entity.User;
import com.cafe.management.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class Authcontroller {

    @Autowired
    private UserService userService;

    @PostMapping("/register") // Added @PostMapping to expose the endpoint
    private ResponseEntity<User> register(@RequestBody User user) {
        return ResponseEntity.ok(userService.registerUser(user)); // Calls UserService to register a new user
    }

    @PostMapping("/login") // Added @PostMapping to map login requests
    public ResponseEntity<String> login(@RequestBody Map<String, String> credentials) {
        // Calls UserService to check credentials
        boolean authenticated = userService.authenticateUser(credentials.get("username"), credentials.get("password"));
        return authenticated ? ResponseEntity.ok("Login successful") : ResponseEntity.status(401).body("Invalid credentials");
    }

}
