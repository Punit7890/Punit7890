package com.cafe.management.service;

import com.cafe.management.entity.Order;
import com.cafe.management.entity.OrderStatus;
import com.cafe.management.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    //Creates a new order and saves it to the database.
    public Order createOrder(Order order) {
        return orderRepository.save(order);
    }

    //Retrieves all orders for a specific customer.
    public List<Order> getOrdersByCustomer(Long customerId) {
       return orderRepository.findByCustomerId(customerId);
    }


    //Retrieves an order by its ID.
    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    //Updates the status of an existing order.
    public Order updateOrderStatus(Long id, OrderStatus status) {
        Optional<Order> order = orderRepository.findById(id);
        if (order.isPresent()) {
            Order existingOrder = order.get();
            existingOrder.setStatus(status);  // Updating the order status
            return orderRepository.save(existingOrder); // Saving the updated order
        }
        return null; //return null if order does not exist
    }

}
