package com.cafe.management.service;

import com.cafe.management.entity.Employee;
import com.cafe.management.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    /**
     * Retrieves all employees from the database.
     * @return List of all employees.
     */
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll(); // Calls the repository method to fetch all employee records
    }

    /**
     * Get employee By EmployeeId from database
     */
    public List<Employee> getEmployeeById(Long id) {
        return employeeRepository.findAll();
    }

    /**
     * Saves a new employee or updates an existing one.
     * @param employee The employee object to be saved.
     * @return The saved employee object.
     */
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee); // Saves the employee entity to the database
    }

    /**
     * Deletes an employee by ID.
     * @param id The ID of the employee to be deleted.
     */
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id); // Deletes the employee with the specified ID
    }
}
