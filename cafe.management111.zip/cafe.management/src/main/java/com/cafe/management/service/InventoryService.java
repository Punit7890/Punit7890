package com.cafe.management.service;

import com.cafe.management.entity.Inventory;
import com.cafe.management.repository.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    /**
     * Retrieves all inventory items from the database.
     * @return List of all inventory items.
     */
    public List<Inventory> getAllInventory() {
        return inventoryRepository.findAll(); // Calls the repository method to fetch all inventory records
    }

    /**
     * Adds a new inventory item to the database.
     * @param inventory The inventory item to be added.
     * @return The saved inventory item.
     */
    public Inventory addInventoryItem(Inventory inventory) {
        return inventoryRepository.save(inventory); // Saves the inventory entity to the database
    }
}
