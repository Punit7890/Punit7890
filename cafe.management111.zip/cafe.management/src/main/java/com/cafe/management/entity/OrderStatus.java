package com.cafe.management.entity;

public enum OrderStatus {
    PENDING, CONFIRMED, PREPARING, COMPLETED, CANCELED
}
