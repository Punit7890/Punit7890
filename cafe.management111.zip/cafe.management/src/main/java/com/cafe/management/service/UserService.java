package com.cafe.management.service;

import com.cafe.management.entity.User;
import com.cafe.management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository; // Repository for accessing user data

    @Autowired
    private PasswordEncoder passwordEncoder; // Encrypts passwords before saving

    @Autowired
    @Lazy
    private AuthenticationManager authenticationManager; // Manages authentication process

    //Registers a new user by encoding their password before saving
    public User registerUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword())); // Encrypts password
        return userRepository.save(user); // Saves user in the database
    }

    //Finds a user by their username.
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username); //retrive user from database
    }

    //Authenticates a user using the provided credentials.
    public boolean authenticateUser(String username, String password) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        return true; //If authentication succeeds, return tru
    }

    //Loads a user by their username (used for Spring Security authentication).
    @Override
    public UserDetails loadUserByUsername(String username) {
        return (UserDetails) userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

}

