//for sending notification via email
//to customer about order confirmation
//to admin about Daily summaries
package com.cafe.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    @Autowired
    private JavaMailSender mailSender;

    /**
     * Sends a plain text email using the configured mail sender.
     * @param to      The recipient's email address
     * @param subject The subject of the email
     * @param body    The body text of the email
     */
    private void sendEmail(String to, String subject, String body) {
        SimpleMailMessage message = new SimpleMailMessage(); // Creates a simple email message
        message.setTo(to); //sets the recipient
        message.setSubject(subject); //set the subject
        message.setText(body); //sets the body content
        mailSender.send(message); //sends the email
    }

    /**
     * Sends an order confirmation email to the customer.
     *
     * @param customerEmail The email address of the customer
     * @param orderDetails  A summary of the customer's order
     */
    public void sendOrderConfirmation(String customerEmail, String orderDetails) {
        sendEmail(customerEmail, "Order Confirmation", orderDetails);
    }

    /**
     * Sends a daily sales summary email to the admin.
     *
     * @param adminEmail The email address of the admin
     * @param summary    The content of the daily sales summary
     */
    public void sendDailySalesSummary(String adminEmail, String summary) {
        sendEmail(adminEmail, "Daily Sales Summary", summary);
    }
}
