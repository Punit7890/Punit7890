package com.cafe.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class main_cafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(main_cafeApplication.class, args);
	}
}
