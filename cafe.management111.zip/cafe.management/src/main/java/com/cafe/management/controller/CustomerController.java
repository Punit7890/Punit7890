package com.cafe.management.controller;

import com.cafe.management.entity.Customer;
import com.cafe.management.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    /**
     * GET endpoint to fetch all customers.
     * URL: /api/customers
     * @return List of all customers in the system.
     */
    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomers() {
        return ResponseEntity.ok(customerService.getAllCustomers()); // Calls service to fetch all customers
    }

    /**
     * GET endpoint to fetch a customer by ID.
     * URL: /api/customers/{id}
     * @param id The ID of the customer to retrieve.
     * @return The customer if found, wrapped in Optional.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Optional<Customer>> getCustomerById(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.getCustomerById(id)); // Calls service to fetch customer by ID
    }

    /**
     * POST endpoint to add a new customer.
     * URL: /api/customers
     * @param customer The customer object from the request body.
     * @return The saved customer entity.
     */
    @PostMapping
    public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) {
        return ResponseEntity.ok(customerService.saveCustomer(customer)); //save customer into database
    }

    /**
     * DELETE endpoint to remove a customer by ID.
     * URL: /api/customers/{id}
     * @param id The ID of the customer to delete.
     * @return Success message on deletion.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id); //delete customer from database
        return ResponseEntity.ok("Customer deleted successfully");
    }
}
