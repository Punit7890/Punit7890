//for Role management
package com.cafe.management.entity;

// Enum for role management
public enum Role {

        ADMIN, STAFF, CUSTOMER
    }

