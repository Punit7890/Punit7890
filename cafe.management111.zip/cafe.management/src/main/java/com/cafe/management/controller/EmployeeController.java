package com.cafe.management.controller;

import com.cafe.management.entity.Employee;
import com.cafe.management.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    public EmployeeService employeeService;

    /**
     * GET endpoint to fetch all employees.
     * URL: /api/employees
     * @return List of all employees.
     */
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(employeeService.getAllEmployees()); // Calls the service to fetch employees
    }

    /**
     * GET endpoint to fetch employee(s) by ID.
     * URL: /api/employees/{id}
     * @param id Employee ID
     * @return List of employees (though ideally should return a single Employee)
     */
    @GetMapping("/{id}")
    public ResponseEntity<List<Employee>> getEmployeeById(@PathVariable Long id) {
        return ResponseEntity.ok(employeeService.getEmployeeById(id)); //it returns a single employee object
    }

    /**
     * POST endpoint to add a new employee.
     * URL: /api/employees
     * @param employee Employee object from request body
     * @return The saved employee
     */
    public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee) {
        return ResponseEntity.ok(employeeService.saveEmployee(employee));  // Saves and returns the new employee
    }


    /**
     * DELETE endpoint to remove an employee by ID.
     * URL: /api/employees/{id}
     * @param id Employee ID to delete
     * @return Confirmation message
     */
    public ResponseEntity<String> deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id); //it calls service to delete the employee
        return ResponseEntity.ok("Employee deleted successfully");
    }
}
