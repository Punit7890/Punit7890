//For Report and Analytics
package com.cafe.management.service;

import com.cafe.management.entity.Sale;
import com.cafe.management.repository.SaleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service // Declares this class as a service for handling business logic
public class ReportService {
    @Autowired
    private SaleRepository saleRepository;

    /**
     * Generates a sales report based on the specified period.
     *
     * @param period The time frame for the report: "daily", "weekly", or "monthly"
     * @return A list of Sale records that occurred after the computed start date
     */
    public List<Sale> getSalesReport(String period) {
        // Determine the starting date based on the requested period
        LocalDateTime startDate = switch (period) {
            case "daily" -> LocalDate.now().atStartOfDay(); //today at 00:00
            case "weekly" -> LocalDate.now().minusWeeks(1).atStartOfDay(); // 7 days ago
            case "monthly" -> LocalDate.now().minusMonths(1).atStartOfDay(); // 30 days ago
            default -> throw new IllegalArgumentException("Invalid period"); // Handle invalid inputs
        };

        // Fetch sales records from the repository that occurred after the calculated start date
        return saleRepository.findSalesAfter(startDate);
    }
}
