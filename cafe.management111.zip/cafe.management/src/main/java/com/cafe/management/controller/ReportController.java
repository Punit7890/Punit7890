//For Report and Analytics
package com.cafe.management.controller;

import com.cafe.management.entity.Sale;
import com.cafe.management.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    /**
     * GET endpoint to retrieve sales reports based on a time period.
     * @param period The report type: "daily", "weekly", or "monthly"
     * @return A list of Sale records for the specified period
     */
    @GetMapping("/sales") // Handles GET requests to /api/reports
    public ResponseEntity<List<Sale>> getSalesReport(@RequestParam String period) {
        return ResponseEntity.ok(reportService.getSalesReport(period)); // Calls service and returns sales data
    }
}
