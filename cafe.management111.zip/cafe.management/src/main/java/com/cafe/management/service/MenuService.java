package com.cafe.management.service;

import com.cafe.management.entity.Menu;
import com.cafe.management.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {

    @Autowired
    private MenuRepository menuRepository;


    /**
     * Retrieves all menu items from the database.
     * @return List of all menu items.
     */
    public List<Menu> getAllItems() {
        return menuRepository.findAll();  // Calls the JPA repository to fetch all records
    }
    //Adds a new menu item to the database.
    public Menu addItem(Menu menu) {
        return menuRepository.save(menu);
    }

    //Delete a menu items by its ID
    public void deletItem(Long id) {
        menuRepository.deleteById(id); // Deletes the menu item with the specified ID
    }

}
