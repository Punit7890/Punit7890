package com.cafe.management.controller;

import com.cafe.management.entity.Inventory;
import com.cafe.management.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    /**
     * Endpoint to retrieve all inventory items.
     * @return HTTP response with a list of inventory items.
     */
    @GetMapping("/all") // Handles GET requests at /api/inventory/all
    public ResponseEntity<List<Inventory>> getAllInventory() {
        return ResponseEntity.ok(inventoryService.getAllInventory()); // Returns the list of all inventory items
    }

    /**
     * Endpoint to add a new inventory item.
     * @param inventory The inventory item received from the request body.
     * @return HTTP response with the added inventory item.
     */
    public ResponseEntity<Inventory> addInventoryItem(@RequestBody Inventory inventory) {
        return ResponseEntity.ok(inventoryService.addInventoryItem(inventory)); // Calls the service to add the item and returns it
    }

}
